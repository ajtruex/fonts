Droid Sans Mono Slashed for Powerline
=====================================

:Font creator: Ascender Corporation (modified by Cosmix)
:Source: http://www.cosmix.org/software/
:Patched by: `toiffel <https://github.com/toiffel>`_

Hack (for Powerline)
=========================

:Font creator: Christopher Simpkins
:Version: 2.020
:Source: https://github.com/chrissimpkins/Hack
:License: Hack Open Font License + Bitstream Vera license
:License URL: https://github.com/chrissimpkins/Hack/blob/master/LICENSE.md
:Patched by: `Christopher Simpkins <https://github.com/chrissimpkins/Hack>`_


Hack is a derivative of the Bitstream Vera Sans Mono and DejaVu Sans Mono glyph sets that includes new glyph shapes and adjustments to the weight and metrics of the typeface.  The Powerline glyphs were patched into the Regular release set by the developer and are released on the source repository in a patched form by default.

It is not necessary to add 'for Powerline' to the Hack family name when you use this typeface in Powerline.
